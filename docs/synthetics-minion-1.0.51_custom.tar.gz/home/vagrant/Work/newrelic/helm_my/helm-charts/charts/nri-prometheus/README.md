This chart has been moved to https://github.com/newrelic/nri-prometheus/tree/main/charts/nri-prometheus
