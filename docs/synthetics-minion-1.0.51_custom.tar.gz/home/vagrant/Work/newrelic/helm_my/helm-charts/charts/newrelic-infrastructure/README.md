This chart has been moved to https://github.com/newrelic/nri-kubernetes/tree/main/charts/newrelic-infrastructure

A maintenance version of the v2 can be found in https://github.com/newrelic/nri-kubernetes/tree/v2/charts/newrelic-infrastructure
