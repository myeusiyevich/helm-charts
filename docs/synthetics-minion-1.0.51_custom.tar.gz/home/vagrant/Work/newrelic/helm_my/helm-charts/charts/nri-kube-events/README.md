This chart has been moved to https://github.com/newrelic/nri-kube-events/tree/main/charts/nri-kube-events
